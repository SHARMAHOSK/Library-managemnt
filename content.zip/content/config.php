<?php
include_once('include/Database.php');
/*define('SS_DB_NAME', 'erp');
define('SS_DB_USER', 'root');
define('SS_DB_PASSWORD', '');
define('SS_DB_HOST', 'localhost');*/
define('SS_DB_NAME', 'erp');
define('SS_DB_USER', 'exway');
define('SS_DB_PASSWORD', '123456xy');
define('SS_DB_HOST', 'mysql-9747-0.cloudclusters.net:9747/exway?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC');


$dsn	= 	"mysql:dbname=".SS_DB_NAME.";host=".SS_DB_HOST."";
$pdo	=	"";
try {
	$pdo = new PDO($dsn, SS_DB_USER, SS_DB_PASSWORD);
}catch (PDOException $e) {
	echo "Connection failed: " . $e->getMessage();
}
$db 	=	new Database($pdo);
?>