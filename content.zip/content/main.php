<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css'>
<link rel="stylesheet" href="css/main.css">
<title>Home</title>
<?php
include_once('config.php');
$data = $db->adminx($login,'semester,roll');
$fine = $data[0]['semester'];
$days = $data[0]['roll'];
$data = $db->queryx("SELECT COUNT(*) FROM `s_info` WHERE type='student'");
$student_c = $data[0]['COUNT(*)'];
$data = $db->queryx("SELECT COUNT(*) FROM `books` WHERE 1");
$books_c = $data[0]['COUNT(*)'];
$data = $db->queryx("SELECT COUNT(*) FROM `book_issue` WHERE 1");
$issue_c = $data[0]['COUNT(*)'];
$t_date = date_format(date_create(),"Y-m-d");
$data = $db->queryx('SELECT COUNT(*) FROM `book_issue` WHERE 1 AND i_date LIKE "%'.$t_date.'%" ');
$issue_t = $data[0]['COUNT(*)'];
$data = $db->queryx('SELECT COUNT(*) FROM `book_issue` WHERE 1 AND r_date LIKE "%'.$t_date.'%" ');
$return_t = $data[0]['COUNT(*)'];
$data = $db->queryx('SELECT COUNT(*) FROM `book_issue` WHERE 1 AND erdate < CURDATE() AND status=1 ');
$pending_fine = $data[0]['COUNT(*)'];
$data = $db->queryx("SELECT COUNT(*) FROM `book_issue` WHERE status=1");
$pen_books = $data[0]['COUNT(*)'];
$data = $db->queryx("SELECT COUNT(*) FROM `books` WHERE active=1");
$act_books = $data[0]['COUNT(*)'];
$data = $db->queryx('SELECT COUNT(*) FROM `book_issue` WHERE 1 AND MONTH(i_date) = MONTH(CURRENT_DATE()) AND YEAR(i_date)=YEAR(CURRENT_DATE())');
$issue_month = $data[0]['COUNT(*)'];
$data = $db->queryx('SELECT COUNT(*) FROM `book_issue` WHERE 1 AND MONTH(r_date) = MONTH(CURRENT_DATE()) AND YEAR(r_date)=YEAR(CURRENT_DATE())');
$return_month = $data[0]['COUNT(*)'];
?>
<style>
body{
background-color:#e2e2e2;
}
</style>
<br>
  <div class="container">
    <div class="row">
      
      <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-graduation icons"></i>
          <div>
            <b><?php echo $student_c; ?></b>
            <span>students</span>
          </div> 
        </div>
      </div> 
      <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-notebook icons"></i>
          <div>
            <b><?php echo $books_c; ?></b>
            <span>books</span>
          </div> 
        </div>
      </div> 
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-book-open icons"></i>
          <div>
            <b><?php echo $issue_c; ?></b>
            <span>issued books</span>
          </div> 
        </div>
      </div> 
      <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-hourglass icons"></i>
          <div>
            <b><?php echo $pending_fine; ?></b>
            <span>pending fines</span>
          </div> 
        </div>
      </div> 
</div>
<div class="row">
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-book-open icons"></i>
          <div>
            <b><?php echo $issue_t; ?></b>
            <span>issued today</span>
          </div> 
        </div>
      </div> 
      <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-hourglass icons"></i>
          <div>
            <b><?php echo $return_t; ?></b>
            <span>returned tody</span>
          </div> 
        </div>
      </div> 
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-book-open icons"></i>
          <div>
            <b><?php echo $act_books; ?></b>
            <span>Active Books</span>
          </div> 
        </div>
      </div> 
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-hourglass icons"></i>
          <div>
            <b><?php echo $pen_books; ?></b>
            <span>Pending Books</span>
          </div> 
        </div>
      </div> 
</div>
<div class="row">
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-speedometer icons"></i>
          <div>
            <b><?php echo $issue_month; ?></b>
            <span>Issued this month</span>
          </div> 
        </div>
      </div> 
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-energy icons"></i>
          <div>
            <b><?php echo $return_month; ?></b>
            <span>Returnd this month</span>
          </div> 
        </div>
      </div> 
	  <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-energy icons"></i>
          <div>
            <b><?php echo $fine; ?> &#x20B9;</b>
            <span>default-fine(per-day)</span>
          </div> 
        </div>
      </div> 
      <div class="col-md-3">
        <div class="stati bg-turquoise">
          <i class="icon-speedometer icons"></i>
          <div>
            <b><?php echo $days; ?> days</b>
            <span>default days</span>
          </div> 
        </div>
      </div> 
</div>
</div>
</br>
</br>
