<?php
session_start();
error_reporting(0);
if($_SESSION['is_login']==true){echo "<script>location.replace('index.php')</script>";}
include_once('config.php');
?>
<title>Login</title>
<style>
		body{
		background-color: lightblue;
		}
</style>
	<div class="container d-flex justify-content-center" style="margin-top:10%;">
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-globe"></i> <strong>Login</strong></div>
			<div class="card-body justify-content-center" style="background-color:#D2D2D2;">
				<?php
				if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rns"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Login Id or password incorrect ! <strong>Please try again..</strong></div>';
				}
				?>
				<div class="col-sm-12">
					<form method="post">
						<div class="row">
							<div class="col-sm-4">
								<div class="form-group">
									<label>Login Id <span class="text-danger">*</span></label>
									<input type="email" name="email" id="email" class="form-control" placeholder="Enter Login id" required>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>Password <span class="text-danger">*</span></label>
									<input type="password" name="pass" id="pass" class="form-control" placeholder="Enter Password" required>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="login" value="login" id="login" class="btn btn-primary"> Login</button></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		
		
		
	</div>
	<?php 
	if(!(isset($_POST['search']) && $_POST['search']=="search")){echo "<br><br><br><br><br><br>";}
	else{echo "<br>";}
	?>
	
	<?php
	if(isset($_POST['login']) && $_POST['login']=="login"){
	$login = $db->login($_POST['email'],$_POST['pass']);
	if($login!=null){
	$_SESSION['is_login'] = TRUE;
	$_SESSION['login']=$login[0]['s_id'];
	echo "<script>location.replace('login.php')</script>";
	}
	else{
		echo "<script>location.replace('login.php?msg=rns')</script>";
	}
	}
	?>