
<title>Student</title>
<br>
<?php include_once('config.php');?>
	<?php
	$condition	=	'';
	if(isset($_REQUEST['s_name']) and $_REQUEST['s_name']!=""){
		$condition	.=	' AND name LIKE "%'.$_REQUEST['s_name'].'%" ';
	}
	if(isset($_REQUEST['s_code']) and $_REQUEST['s_code']!=""){
		$condition	.=	' AND roll LIKE "%'.$_REQUEST['s_code'].'%" ';
	}
	if(isset($_REQUEST['s_type']) and $_REQUEST['s_type']!=""){
		$condition	.=	' AND branch LIKE "%'.$_REQUEST['s_type'].'%" ';
	}
	if(isset($_REQUEST['s_sem']) and $_REQUEST['s_sem']!=""){
		$condition	.=	' AND semester LIKE "%'.$_REQUEST['s_sem'].'%" ';
	}
	if(isset($_REQUEST['s_email']) and $_REQUEST['s_email']!=""){
		$condition	.=	' AND email LIKE "%'.$_REQUEST['s_email'].'%" ';
	}
	$student = 'student';
	$condition	.=	" AND type='student' ";
	$userData	=	$db->getAllRecords('s_info','*',$condition,'ORDER BY s_id DESC');
	?>
   	<div class="container">
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-globe"></i> <strong>Browse Students</strong> <a href="add-students.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-plus-circle"></i> Add Students</a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<?php
				if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rds"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record deleted successfully!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rus"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record updated successfully!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rnu"){
					echo	'<div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> You did not change any thing!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> There is some thing wrong <strong>Please try again!</strong></div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record Inserted successfully!</div>';
				}
				?>
				<div class="col-sm-12">
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Find Students</h5>
					<form method="get">
						<div class="row">
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Name</label>
									<input type="text" name="s_name" id="s_name" class="form-control" value="<?php echo isset($_REQUEST['s_name'])?$_REQUEST['s_name']:''?>" placeholder="Enter Student Name">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Roll Number</label>
									<input type="text" name="s_code" id="s_code" class="form-control" value="<?php echo isset($_REQUEST['s_code'])?$_REQUEST['s_code']:''?>" placeholder="Enter Roll Number">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Branch</label>
									<input type="text" name="s_type" id="s_type" class="form-control" value="<?php echo isset($_REQUEST['s_type'])?$_REQUEST['s_type']:''?>" placeholder="Enter Branch">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Semester</label>
									<input type="text" name="s_sem" id="s_sem" class="form-control" value="<?php echo isset($_REQUEST['s_sem'])?$_REQUEST['s_sem']:''?>" placeholder="Enter Semester">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student email</label>
									<input type="email" name="s_email" id="s_email" class="form-control" value="<?php echo isset($_REQUEST['s_email'])?$_REQUEST['s_email']:''?>" placeholder="Enter Email">
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="submit" value="search" id="submit" class="btn btn-primary"><i class="fa fa-fw fa-search"></i> Search</button></td>
										<td><a href="<?php echo $_SERVER['PHP_SELF'];?>" class="btn btn-danger"><i class="fa fa-fw fa-sync"></i> Refresh</a></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<hr>
		
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr class="text-white" style="background: rgb(26, 188, 156);">
						<th>Sr#</th>
						<th class="text-center">Roll Number</th>
						<th>Student Name</th>
						<th>email</th>
						<th>Branch</th>
						<th class="text-center">Semester</th>
						<th class="text-center">Pending Books</th>
						<th class="text-center"></th>
					</tr>
				</thead>
				<tbody>
					<?php 
					if(count($userData)>0){
						$s	=	'';
						foreach($userData as $val){
						$s++;
						$condition = "WHERE s_id='".$val['roll']."' AND status='1'";
						$ibx =  $db->getIssuedBooks('book_issue',$condition);
					?>
					<tr>
						<td><?php echo $s;?></td>
						<td align="center"><?php echo $val['roll'];?></td>
						<td><a href="student-profile.php?sid=<?php echo $val['s_id'];?>" style="color:blue;"><?php echo $val['name'];?></a></td>
						<td><?php echo $val['email'];?></td>
						<td><?php echo $val['branch'];?></td>
						<td align="center"><?php echo $val['semester'];?></td>
						<td align="center"><?php print_r($ibx[0]['COUNT(*)']);?></td>
						<td align="center">
						<?php  
						if($ibx[0]['COUNT(*)']==0){
						?>
							<a href="update-student.php?editId=<?php echo $val['s_id'];?>" class="text-primary"><i class="fa fa-fw fa-edit"></i>Edit</a> | 
							<a href="delete-student.php?delId=<?php echo $val['s_id'];?>" class="text-danger" onClick="return confirm('Are you sure to delete this Book?');"><i class="fa fa-fw fa-trash"></i> Delete</a>
						<?php } ?>
						</td>

					</tr>
					<?php 
						}
					}
					else{
					?>
					<tr><td colspan="6" align="center">No Record(s) Found!</td></tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
		
	</div>
	<br>