<title>Edit Books</title>
<br>
<?php include_once('config.php');
if(isset($_REQUEST['editId']) and $_REQUEST['editId']!=""){
	$row	=	$db->getAllRecords('books','*',' AND book_id="'.$_REQUEST['editId'].'"');
}

if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){
	extract($_REQUEST);
	if($b_name==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=bn&editId='.$_REQUEST['editId']);
		exit;
	}elseif($b_auth==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ba&editId='.$_REQUEST['editId']);
		exit;
	}elseif($b_publ==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=bp&editId='.$_REQUEST['editId']);
		exit;
	}elseif($b_type==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=bt&editId='.$_REQUEST['editId']);
		exit;
	}elseif($b_price==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=bpr&editId='.$_REQUEST['editId']);
		exit;
	}
	$data	=	array(
					'book_name'=>$b_name,
					'book_auth'=>$b_auth,
					'book_publ'=>$b_publ,
					'book_type'=>$b_type,
					'book_price'=>$b_price,
					);
	$update	=	$db->update('books',$data,array('book_id'=>$editId));
	if($update){
		header('location:books.php?msg=rus');
		exit;
	}else{
		header('location:books.php?msg=rnu');
		exit;
	}
}
?>	
   	<div class="container">
		<?php
		if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="bn"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Book name is mandatory field!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ba"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Book authentication is mandatory field!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="up"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User phone is mandatory field!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){
			echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record added successfully!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Record not added <strong>Please try again!</strong></div>';
		}
		?>
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-plus-circle"></i> <strong>Update Book</strong> <a href="books.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-globe"></i> Browse Books</a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<div class="col-sm-6">
					<h5 class="card-title">Fields with <span class="text-danger">*</span> are mandatory!</h5>
					<form method="post">
						<div class="form-group">
							<label>Book Name <span class="text-danger">*</span></label>
							<input type="text" name="b_name" id="b_name" class="form-control" value="<?php echo $row[0]['book_name']; ?>" placeholder="Enter Book Name" required>
						</div>
						<div class="form-group">
							<label>Book Auther<span class="text-danger">*</span></label>
							<input type="text" name="b_auth" id="b_auth" class="form-control" value="<?php echo $row[0]['book_auth']; ?>" placeholder="Enter Auther Name" required>
						</div>
						<div class="form-group">
							<label>Book Publisher<span class="text-danger">*</span></label>
							<input type="text" name="b_publ" id="b_publ" class="form-control" value="<?php echo $row[0]['book_publ']; ?>" placeholder="Enter Publisher Name" required>
						</div>
						<div class="form-group">
							<label>Book Type<span class="text-danger">*</span></label>
							<input type="text" name="b_type" id="b_type" class="form-control" value="<?php echo $row[0]['book_type']; ?>" placeholder="Enter user phone" required>
						</div>
						<div class="form-group">
							<label>Book Price<span class="text-danger">*</span></label>
							<input type="number" name="b_price" id="b_price" class="form-control" value="<?php echo $row[0]['book_price']; ?>" placeholder="Enter user phone" required>
						</div>
						<div class="form-group">
							<input type="hidden" name="editId" id="editId" value="<?php echo $_REQUEST['editId']?>">
							<button type="submit" name="submit" value="submit" id="submit" class="btn" style="background: rgb(26, 188, 156);color:white;"><i class="fa fa-fw fa-edit"></i> Update Book</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<br>
	</div>