<title>Books</title>
<br>
<?php include_once('config.php');?>
<style>
	.gdot {
	  height: 11px;
	  width: 11px;
	  background-color: green;
	  border-radius: 50%;
	  display: inline-block;
	}
	.rdot {
	  height: 11px;
	  width: 11px;
	  background-color: red;
	  border-radius: 50%;
	  display: inline-block;
	}
</style>
	<?php
	$condition	=	'';
	if(isset($_REQUEST['b_name']) and $_REQUEST['b_name']!=""){
		$condition	.=	' AND book_name LIKE "%'.$_REQUEST['b_name'].'%" ';
	}
	if(isset($_REQUEST['b_code']) and $_REQUEST['b_code']!=""){
		$condition	.=	' AND book_quan LIKE "%'.$_REQUEST['b_code'].'%" ';
	}
	if(isset($_REQUEST['b_type']) and $_REQUEST['b_type']!=""){
		$condition	.=	' AND book_type LIKE "%'.$_REQUEST['b_type'].'%" ';
	}
	
	$userData	=	$db->getAllRecords('books','*',$condition,'ORDER BY book_id DESC');
	?>
   	<div class="container">
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-globe"></i> <strong>Browse Books</strong> <a href="add-book.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-plus-circle"></i> Add Books</a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<?php
				if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rds"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record deleted successfully!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rus"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record updated successfully!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rnu"){
					echo	'<div class="alert alert-warning"><i class="fa fa-exclamation-triangle"></i> You did not change any thing!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> There is some thing wrong <strong>Please try again!</strong></div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record Inserted successfully!</div>';
				}
				?>
				<div class="col-sm-12">
					<h5 class="card-title"><i class="fa fa-fw fa-search"></i> Find Books</h5>
					<form method="get">
						<div class="row">
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Name</label>
									<input type="text" name="b_name" id="b_name" class="form-control" value="<?php echo isset($_REQUEST['b_name'])?$_REQUEST['b_name']:''?>" placeholder="Enter Book Name">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Code</label>
									<input type="number" name="b_code" id="b_code" class="form-control" value="<?php echo isset($_REQUEST['b_code'])?$_REQUEST['b_code']:''?>" placeholder="Enter Book Code">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Type</label>
									<input type="text" name="b_type" id="b_type" class="form-control" value="<?php echo isset($_REQUEST['b_type'])?$_REQUEST['b_type']:''?>" placeholder="Enter Book Type">
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="submit" value="search" id="submit" class="btn btn-primary"><i class="fa fa-fw fa-search"></i> Search</button></td>
										<td><a href="<?php echo $_SERVER['PHP_SELF'];?>" class="btn btn-danger"><i class="fa fa-fw fa-sync"></i> Refresh</a></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<hr>
		
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr class="text-white" style="background: rgb(26, 188, 156);">
						<th>Sr#</th>
						<th class="text-center">Book Code</th>
						<th>Book Name</th>
						<th>Book Auther</th>
						<th>Publisher Name</th>
						<th class="text-center">Type</th>
						<th class="text-center">Price</th>
						<th class="text-center">Active</th>
						<th class="text-center"></th>
					</tr>
				</thead>
				<tbody>
					<?php 
					if(count($userData)>0){
						$s	=	'';
						foreach($userData as $val){
							$s++;
					?>
					<tr>
						<td><?php echo $s;?></td>
						<td align="center"><?php echo $val['book_quan'];?></td>
						<td><?php echo $val['book_name'];?></td>
						<td><?php echo $val['book_auth'];?></td>
						<td><?php echo $val['book_publ'];?></td>
						<td align="center"><?php echo $val['book_type'];?></td>
						<td align="center"><?php echo $val['book_price'];?></td>
						<td align="center"><div style="text-align:center"><span class="<?php if($val['active']==1){echo 'gdot';}else{echo 'rdot';}?>"></span></div></td>
						<td align="center">
							<?php if($val['active']==1){ ?>
							<a href="update-book.php?editId=<?php echo $val['book_id'];?>" class="text-primary"><i class="fa fa-fw fa-edit"></i> Edit</a> | 
							<a href="delete.php?delId=<?php echo $val['book_id'];?>" class="text-danger" onClick="return confirm('Are you sure to delete this Book?');"><i class="fa fa-fw fa-trash"></i> Delete</a>
							<?php } ?>
						</td>

					</tr>
					<?php 
						}
					}else{
					?>
					<tr><td colspan="6" align="center">No Record(s) Found!</td></tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
		
	</div>
	<br>