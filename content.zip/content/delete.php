<?php 
include_once('config.php');
if(isset($_REQUEST['delId']) and $_REQUEST['delId']!=""){
	$db->delete('books',array('book_id'=>$_REQUEST['delId']));
	header('location:books.php?msg=rds');
	exit;
}
?>