<div id="1"><?php include 'content/header.php';?></div>
<div id="2"><?php include 'content/animlogin.php';?></div>
<div id="3"><?php include 'content/footer.html';?></div>