<title>Profile</title>
<br>
<?php include_once('config.php');?>
	<?php
	$condition 	=   "s_id ='".$_REQUEST['sid']."'";
	$userData	=	$db->getMyRecords('s_info','*',$condition);
	$condition 	=   "s_id ='".$userData[0]['roll']."'";
	$issueData  =   $db->getMyRecords('book_issue','*',$condition);
	?>
   	<div class="container">
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-globe"></i> <strong> Student Information</strong> <a href="students.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-globe"></i> Browse Students </a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<div class="col-sm-12">
					<form method="get">
						<div class="row">
							<div class="col-sm-4">
								<div class="form-group">
									<label>Student Name</label>
									<input type="text" name="s_name" id="s_name" class="form-control" value="<?php echo $userData[0]['name']?>" readonly>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>Roll Number</label>
									<input type="text" name="s_code" id="s_code" class="form-control" value="<?php echo $userData[0]['roll']?>" readonly>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>Student Branch</label>
									<input type="text" name="s_type" id="s_type" class="form-control" value="<?php echo $userData[0]['branch']?>" readonly>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>Student Semester</label>
									<input type="text" name="s_sem" id="s_sem" class="form-control" value="<?php echo $userData[0]['semester']?>" readonly>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>Student email</label>
									<input type="email" name="s_email" id="s_email" class="form-control" value="<?php echo $userData[0]['email']?>" readonly>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>Student Register date</label>
									<input type="email" name="s_email" id="s_email" class="form-control" value="<?php echo $userData[0]['RegDate']?>" readonly>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<hr>
		
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr class="text-white" style="background: rgb(26, 188, 156);">
						<th>Sr#</th>
						<th class="text-center">Book Code</th>
						<th>Book Name</th>
						<th>Issue date</th>
						<th>Expected Return date</th>
						<th>Return Date</th>
						<th class="text-center">Fine</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					if(count($issueData)>0){
						$s	=	'';
						foreach($issueData as $val){
						$s++;
						$condition = "book_quan='".$val['b_id']."'";
						$field = "book_name,book_quan";
						$ibx =  $db->getMyRecords('books',$field,$condition);
					?>
					<tr>
						<td><?php echo $s;?></td>
						<td align="center"><?php echo $ibx[0]['book_quan'];?></td>
						<td><?php echo $ibx[0]['book_name'];?></td>
						<td><?php echo $val['i_date'];?></td>
						<td><?php echo $val['erdate'];?></td>
						<td align="center"><?php if($val['r_date']!=null){echo $val['r_date'];}else{echo "<span style='color:red;'>Pending...<span>";}?></td>
						<td align="center"><?php if($val['fine']!=null){echo $val['fine']." &#8377";}else{echo "<span style='color:red;'>Pending...<span>";}?></td>
					</tr>
					<?php 
						}
					}
					else{
					?>
					<tr><td colspan="7" align="center">No Record(s) Found!</td></tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
		
	</div>
	<br>