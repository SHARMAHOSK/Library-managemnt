<br>
<title>Add book</title>
<?php include_once('config.php');
if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){
	extract($_REQUEST);
	if($b_name==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
		exit;
	}elseif($b_auth==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');
		exit;
	}elseif($b_publ==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');
		exit;
	}elseif($b_code==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');
		exit;
	}elseif($b_type==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');
		exit;
	}elseif($b_price==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');
		exit;
	}else{
		
		$userCount	=	$db->getQueryCount('books','book_id');
		if($userCount[0]['total']<20){
			$data	=	array(
							'book_name'=>$b_name,
							'book_auth'=>$b_auth,
							'book_publ'=>$b_publ,
							'book_quan'=>$b_code,
							'book_type'=>$b_type,
							'book_price'=>$b_price,
						);
			$insert	=	$db->insert('books',$data);
			if($insert){
				header('location:books.php?msg=ras');
				exit;
			}else{
				header('location:books.php?msg=rna');
				exit;
			}
		}else{
			header('location:'.$_SERVER['PHP_SELF'].'?msg=dsd');
			exit;
		}
	}
}
?>
   	<div class="container">

		<?php

		if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="un"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User name is mandatory field!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ue"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User email is mandatory field!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="up"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> User phone is mandatory field!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){

			echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record added successfully!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Record not added <strong>Please try again!</strong></div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="dsd"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Please delete a user and then try again <strong>We set limit for security reasons!</strong></div>';

		}

		?>

		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-plus-circle"></i> <strong>Add Book</strong> <a href="books.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-globe"></i> Browse Books</a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<div class="col-sm-6">
					<h5 class="card-title">Fields with <span class="text-danger">*</span> are mandatory!</h5>
					<form method="post">
						<div class="form-group">
							<label>Book Name<span class="text-danger">*</span></label>
							<input type="text" name="b_name" id="b_name" class="form-control" placeholder="Enter Book name" required>
						</div>
						<div class="form-group">
							<label>Auther Name<span class="text-danger">*</span></label>
							<input type="text" name="b_auth" id="b_auth" class="form-control" placeholder="Enter Auther Name" required>
						</div>
						<div class="form-group">
							<label>Book Publisher<span class="text-danger">*</span></label>
							<input type="text" name="b_publ" id="b_publ" class="form-control" placeholder="Enter Publisher Name" required>
						</div>
						<div class="form-group">
							<label>Book Code<span class="text-danger">*</span></label>
							<input type="number" name="b_code" id="b_code" class="form-control" placeholder="Enter Book Code" required>
						</div>
						<div class="form-group">
							<label>Book Type<span class="text-danger">*</span></label>
							<input type="text" name="b_type" id="b_type" class="form-control" placeholder="Enter user phone" required>
						</div>
						<div class="form-group">
							<label>Book Price<span class="text-danger">*</span></label>
							<input type="number" name="b_price" id="b_price" class="form-control" placeholder="Enter user phone" required>
						</div>
						<div class="form-group">
							<button type="submit" name="submit" value="submit" id="submit" class="btn" style="background: rgb(26, 188, 156);color:white;"><i class="fa fa-fw fa-plus-circle"></i> Add Book</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<br>