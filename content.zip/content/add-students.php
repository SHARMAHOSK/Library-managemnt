<title>add student</title>
<br>
<?php include_once('config.php');
if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){
	extract($_REQUEST);
	if($s_name==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=un');
		exit;
	}elseif($s_type==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=up');
		exit;
	}elseif($s_email==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');
		exit;
	}elseif($s_sem==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue');
		exit;
	}else{
		$userCount	=	$db->getQueryCount('s_info','s_id');
		$val_email  =   $db->checkEmailVal('s_info',$s_email);
		if($val_email){
			if($userCount[0]['total']<20){
			$data	=	array(
							'name'=>$s_name,
							'branch'=>$s_type,
							'semester'=>$s_sem,
							'email'=>$s_email,
						);
			$insert =	$db->insert('s_info',$data);
			if($insert){
				$condition  =   "email = '".$s_email."'";
				$myData		=	$db->getMyRecords('s_info','s_id',$condition);
				$s_code     =   "JIM000".$myData[0]['s_id'];
				echo $s_code;
				$update		=	$db->update('s_info',array('roll'=>$s_code),array('s_id'=>$myData[0]['s_id']));
				if($update){
				header('location:students.php?msg=ras');
				exit;
				}else{
				header('location:students.php?msg=rna');
				exit;
				}
			}else{
				header('location:students.php?msg=rna');
				exit;
			}
		}else{
			header('location:'.$_SERVER['PHP_SELF'].'?msg=dsd');
			exit;
		}
		}else{
			header('location:add-students.php?msg=env');
		}
	}
}
?>
   	<div class="container">

		<?php

		if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="un"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Student name is mandatory field!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ue"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Student email is mandatory field!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="up"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Student phone is mandatory field!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){

			echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record added successfully!</div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Record not added <strong>Please try again!</strong></div>';

		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="dsd"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Please delete a user and then try again <strong>We set limit for security reasons!</strong></div>';

		}
		elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="env"){

			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Email Already exists <strong>Pleace try another email</strong></div>';

		}

		?>

		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-plus-circle"></i> <strong>Add Student</strong> <a href="students.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-globe"></i> Browse Student</a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<div class="col-sm-6">
					<h5 class="card-title">Fields with <span class="text-danger">*</span> are mandatory!</h5>
					<form method="post">
						<div class="form-group">
							<label>Student Name<span class="text-danger">*</span></label>
							<input type="text" name="s_name" id="s_name" class="form-control" placeholder="Enter Student Name" required>
						</div>
						<div class="form-group">
							<label>Student Email id<span class="text-danger">*</span></label>
							<input type="text" name="s_email" id="s_email" class="form-control" placeholder="Enter Email id" required>
						</div>
						<div class="form-group">
							<label>Student Branch<span class="text-danger">*</span></label>
							<input type="text" name="s_type" id="s_type" class="form-control" placeholder="Enter Branch" required>
						</div>
						<div class="form-group">
							<label>Student Semester<span class="text-danger">*</span></label>
							<input type="number" name="s_sem" id="s_sem" class="form-control" placeholder="Enter Semester" required>
						</div>
						<div class="form-group">
							<button type="submit" name="submit" value="submit" id="submit" class="btn" style="background: rgb(26, 188, 156);color:white;"><i class="fa fa-fw fa-plus-circle"></i> Add Book</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		<br>
	</div>