<?php
session_start();
error_reporting(0);
if($_SESSION['is_login']!=true){echo "<script>location.replace('login.php')</script>";}
$login = $_SESSION['login'];
?>
<?php include 'content/header.php';?>
<?php include 'content/main.php';?>
<?php include 'content/footer.html';?>