<?php
session_start();
error_reporting(0);
if($_SESSION['is_login']!=true){echo "<script>location.replace('login.php')</script>";}
include_once('config.php');
?>
<?php include 'content/header.php';?>
<?php include 'content/browse-students.php';?>
<?php include 'content/footer.html';?>