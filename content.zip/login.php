<?php include 'content/header.php';?>
<?php include 'content/login.php';?>
<?php include 'content/footer.html';?>