<title>Edit student</title>
<?php include_once('config.php');
if(isset($_REQUEST['editId']) and $_REQUEST['editId']!=""){
	$row	=	$db->getAllRecords('s_info','*',' AND s_id="'.$_REQUEST['editId'].'"');
}

if(isset($_REQUEST['submit']) and $_REQUEST['submit']!=""){
	extract($_REQUEST);
	if($s_name==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=un&editId='.$_REQUEST['editId']);
		exit;
	}elseif($s_email==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=ue&editId='.$_REQUEST['editId']);
		exit;
	}elseif($s_type==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=up&editId='.$_REQUEST['editId']);
		exit;
	}elseif($s_sem==""){
		header('location:'.$_SERVER['PHP_SELF'].'?msg=up&editId='.$_REQUEST['editId']);
		exit;
	}
	$data	=	array(
					'name'=>$s_name,
					'branch'=>$s_type,
					'semester'=>$s_sem,
					'email'=>$s_email,
					);
	$update	=	$db->update('s_info',$data,array('s_id'=>$editId));
	if($update){
		header('location:students.php?msg=rus');
		exit;
	}else{
		header('location:students.php?msg=rnu');
		exit;
	}
}
?>	
   	<div class="container">
		<?php
		if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="un"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Student name is mandatory field!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ue"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Student email is mandatory field!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="up"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Student phone is mandatory field!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="ras"){
			echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record added successfully!</div>';
		}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
			echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Record not added <strong>Please try again!</strong></div>';
		}
		?>
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-plus-circle"></i> <strong>Update Student</strong> <a href="students.php" class="float-right btn btn-dark btn-sm"><i class="fa fa-fw fa-globe"></i> Browse Students</a></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<div class="col-sm-6">
					<h5 class="card-title">Fields with <span class="text-danger">*</span> are mandatory!</h5>
					<form method="post">
						<div class="form-group">
							<label>Student Name<span class="text-danger">*</span></label>
							<input type="text" name="s_name" id="s_name" value="<?php echo $row[0]['name']; ?>" class="form-control" placeholder="Enter Student Name" required>
						</div>
						<div class="form-group">
							<label>Student Email id<span class="text-danger">*</span></label>
							<input type="text" name="s_email" id="s_email" value="<?php echo $row[0]['email']; ?>" class="form-control" placeholder="Enter Email id" required>
						</div>
						<div class="form-group">
							<label>Student Branch<span class="text-danger">*</span></label>
							<input type="text" name="s_type" id="s_type" value="<?php echo $row[0]['branch']; ?>" class="form-control" placeholder="Enter Branch" required>
						</div>
						<div class="form-group">
							<label>Student Semester<span class="text-danger">*</span></label>
							<input type="number" name="s_sem" id="s_sem" value="<?php echo $row[0]['semester']; ?>" class="form-control" placeholder="Enter Semester" required>
						</div>
						<div class="form-group">
							<input type="hidden" name="editId" id="editId" value="<?php echo $_REQUEST['editId']?>">
							<button type="submit" name="submit" value="submit" id="submit" class="btn" style="background: rgb(26, 188, 156);color:white;"><i class="fa fa-fw fa-edit"></i> Update Book</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>