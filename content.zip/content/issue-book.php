<title>Issue</title>
<br>
<?php include_once('config.php');?>
	<?php
	$condition	=	'';
	if(isset($_REQUEST['s_code']) and $_REQUEST['s_code']!=""){
	$condition	.=	' AND s_id LIKE "%'.$_REQUEST['s_code'].'%" ';
	}
	if(isset($_REQUEST['b_code']) and $_REQUEST['b_code']!=""){
	$condition	.=	' AND b_id LIKE "%'.$_REQUEST['b_code'].'%" ';
	}
	if(isset($_REQUEST['i_date']) and $_REQUEST['i_date']!=""){
		$condition	.=	' AND i_date LIKE "%'.$_REQUEST['i_date'].'%" ';
	}
	if(isset($_REQUEST['status']) and $_REQUEST['status']!=""){
		$condition	.=	' AND status LIKE "%'.$_REQUEST['status'].'%" ';
	}
	
	$userData	=	$db->getAllRecords('book_issue','*',$condition,'ORDER BY id DESC');
	?>
	
   	<div class="container">
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-globe"></i> <strong>Issue Books</strong></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<?php
				if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rds"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Record Issued successfully!</div>';
				}elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rna"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> There is some thing wrong in roll number and book code <strong>Please try again!</strong></div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="bna"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> book not active <strong>Please issue another book!</strong></div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="bni"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> book not issued <strong>Something wrong!</strong></div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="bnu"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> book issued but status not changed.. <strong>Something wrong!</strong></div>';
				}
				?>
				<div class="col-sm-12">
					<form method="post">
						<div class="row">
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Roll Number <span class="text-danger">*</span></label>
									<input type="text" name="code" id="code" class="form-control" placeholder="Enter Roll Number" required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Code <span class="text-danger">*</span></label>
									<input type="text" name="book" id="book" class="form-control" placeholder="Enter Book Code" required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Issue Days <span class="text-danger">*</span></label>
									<input type="text" name="i_day" id="i_day" class="form-control" placeholder="Enter Issue Days" required>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="issue" value="issue" id="submit" class="btn btn-primary"><i class="fa fa-paper-plane"></i> Issue Book</button></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<hr>
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-search"></i> <strong>Find Issue Books Data</strong></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<div class="col-sm-12">
					<form method="get">
						<div class="row">
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Roll Number</label>
									<input type="text" name="s_code" id="s_code" class="form-control" value="<?php echo isset($_REQUEST['s_code'])?$_REQUEST['s_code']:''?>" placeholder="Enter Roll Number">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Code</label>
									<input type="text" name="b_code" id="b_code" class="form-control" value="<?php echo isset($_REQUEST['b_code'])?$_REQUEST['b_code']:''?>" placeholder="Enter Book Code">
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Issue Date</label>
									<input type="date" name="i_date" id="i_date" class="form-control" value="<?php echo isset($_REQUEST['i_date'])?$_REQUEST['i_date']:''?>" >
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Only Pending</label>
									<select class="form-control" id="status" name="status">
									<option value='' default></option>
									<option value='1'>Yes</option>
									<option value='0'>No</option>
									</select>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="submit" value="search" id="submit" class="btn btn-primary"><i class="fa fa-fw fa-search"></i> Search</button></td>
										<td><a href="<?php echo $_SERVER['PHP_SELF'];?>" class="btn btn-danger"><i class="fa fa-fw fa-sync"></i> Refresh</a></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		
		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<thead>
					<tr class="text-white" style="background: rgb(26, 188, 156);">
						<th>Sr#</th>
						<th class="text-center">Student Name</th>
						<th>Roll Number</th>
						<th>Book Name</th>
						<th>Book Code</th>
						<th class="text-center">Issue Date</th>
						<th class="text-center">Expected Return Date</th>
						<th class="text-center">Return Date</th>
						<th class="text-center">Fine</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					if(count($userData)>0){
						$s	=	'';
						foreach($userData as $val){
						$s++;
						$condition = "book_quan='".$val['b_id']."'";
						$field = "book_name,book_quan";
						$ibx =  $db->getMyRecords('books',$field,$condition);
						$condition = "roll='".$val['s_id']."'";
						$field = "name,roll";
						$iby =  $db->getMyRecords('s_info',$field,$condition);
						
					?>
					<tr>
						<td><?php echo $s;?></td>
						<td><?php echo $iby[0]['name']; ?></td>
						<td><?php echo $iby[0]['roll']; ?></td>
						<td><?php echo $ibx[0]['book_name']; ?></td>
						<td><?php echo $ibx[0]['book_quan']; ?></td>
						<td align="center"><?php echo $val['i_date']; ?></td>
						<td align="center"><?php echo $val['erdate']; ?></td>
						<td align="center"><?php if($val['r_date']!=null){echo $val['r_date'];}else{echo "<span class='text-danger'>Pending....</span>";} ?></td>
						<td align="center"><?php if($val['fine']!=null){echo $val['fine'];}else{echo "<span class='text-danger'>Pending....</span>";} ?></td>
					</tr>
					<?php 
						}
					}
					else{
					?>
					<tr><td colspan="9" align="center">No Record(s) Found!</td></tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
	
	
	
	<?php
	if(isset($_POST['issue']) && $_POST['issue']=="issue"){
	$val_stud = $db->getMyRecords('s_info','roll',"roll='".$_POST['code']."'");
	$val_book = $db->getMyRecords('books','active',"book_quan='".$_POST['book']."'");
	if($val_book!=null && $val_stud!=null){
		if($val_book[0]['active']){
		$data = array(
		's_id'=>$_POST['code'],
		'b_id'=>$_POST['book'],
		'erdate'=>date_format(date_add(date_create(),date_interval_create_from_date_string($_POST['i_day'].' days')),'Y-m-d'),
		'days'=>$_POST['i_day'],
		);
		$insert = $db->insert('book_issue',$data);
		if($insert){
		$update = $db->book_active($_POST['book']);
		if($update){echo "<script>location.replace('issue-book.php?msg=rds');</script>";}
		else{echo "<script>location.replace('issue-book.php?msg=bnu');</script>";}
		}else{echo "<script>location.replace('issue-book.php?msg=bni');</script>";}
		}
		else{
		echo "<script>location.replace('issue-book.php?msg=bna');</script>";
		}
	}else{
		echo "<script>location.replace('issue-book.php?msg=rna');</script>";
		}
	}
	?>
	<br>