<title>return</title>
<br>
<?php include_once('config.php');?>
   	<div class="container">
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-globe"></i> <strong>Return Books</strong></div>
			<div class="card-body" style="background-color:#D2D2D2;">
				<?php
				if(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rds"){
					echo	'<div class="alert alert-success"><i class="fa fa-thumbs-up"></i> Book Return Successfully</div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rns"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i>something wrong !</strong></div>';
				}
				elseif(isset($_REQUEST['msg']) and $_REQUEST['msg']=="rxs"){
					echo	'<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i>something wrong !--</strong></div>';
				}
				?>
				<div class="col-sm-12">
					<form method="post">
						<div class="row">
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Roll Number <span class="text-danger">*</span></label>
									<input type="text" name="code" id="code" class="form-control" placeholder="Enter Roll Number" required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Code <span class="text-danger">*</span></label>
									<input type="text" name="book" id="book" class="form-control" placeholder="Enter Book Code" required>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="search" value="search" id="search" class="btn btn-primary"><i class="fa fa-fw fa-search"></i> Search Data</button></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<hr>
		<div class="card">
			<div class="card-header" style="background: rgb(26, 188, 156);"><i class="fa fa-fw fa-search"></i> <strong>Details of issue data</strong></div>
			<div class="card-body" style="background-color:#D2D2D2;">
			<?php
			if(isset($_POST['search']) && $_POST['search']=="search"){ 
			$condition =  "s_id ='".$_POST['code']."' and b_id='".$_POST['book']."' and status='1'";
			$userData  =  $db->getMyRecords('book_issue','*',$condition);
			if($userData!=null){
			$condition =  "roll ='".$_POST['code']."'";
			$sName = $db->getMyRecords('s_info','name',$condition);
			$condition =  "book_quan ='".$_POST['book']."'";
			$bName = $db->getMyRecords('books','book_name',$condition);
			$edate = $userData[0]['erdate'];
			$rdate = date_format(date_create(),"Y-m-d");
			$ldays = date_diff(date_create($edate),date_create($rdate))->format("%R%a");
			if($ldays>0){$fine  = $ldays*5;}
			else{$fine  = '0';}
			
			?>
				<div class="col-sm-12">
					<form method="POST">
						<div class="row">
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Name</label>
									<input type="text" name="s_name" id="s_name" class="form-control" value="<?php echo $sName[0]['name']; ?>" readonly>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Student Roll Number</label>
									<input type="text" name="s_code" id="s_code" class="form-control" value="<?php echo $userData[0]['s_id']; ?>" readonly required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Name</label>
									<input type="text" name="b_namee" id="b_name" class="form-control" value="<?php echo $bName[0]['book_name']; ?>" readonly>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Book Code</label>
									<input type="text" name="b_code" id="b_code" class="form-control" value="<?php echo $userData[0]['b_id']; ?>" readonly required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Issue Date</label>
									<input type="text" name="i_date" id="i_date" class="form-control" value="<?php echo $userData[0]['i_date']; ?>" readonly>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Expected Return</label>
									<input type="text" name="edate" id="edate" class="form-control" value="<?php echo $edate; ?>" readonly>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Return Date (Today)</label>
									<input type="text" name="rdate" id="rdate" class="form-control" value="<?php echo $rdate; ?>" readonly required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Late days</label>
									<input type="hidden" name="ldays" id="ldays" class="form-control" value="<?php echo $ldays; ?>" readonly required>
									<input type="text"  class="form-control" value="<?php echo $ldays." days"; ?>" readonly required>
								</div>
							</div>
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>Fine</label>
									<input type="hidden" name="fine" id="fine" class="form-control" value="<?php echo $fine; ?>" readonly required>
									<input type="text"  class="form-control" value="<?php echo $fine." &#8377;"; ?>" readonly required>
								</div>
							</div>
							&nbsp;&nbsp;
							<div class="col-sm-2.5">
								<div class="form-group">
									<label>&nbsp;</label>
									<div>
										<table>
										<tr>
										<td><button type="submit" name="return" value="return" id="return" class="btn btn-primary"><i class="fa fa-fw fa-search"></i> Return </button></td>
										<td><a href="<?php echo $_SERVER['PHP_SELF'];?>" class="btn btn-danger"><i class="fa fa-fw fa-sync"></i> Cancel</a></td>
										</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			<?php }
			else{
				echo "<tr><td colspan='12' align='center'>No Record(s) Found!</td></tr>";
			}
			}else{ ?>
			<tr><td colspan="12" align="center"> You have to enter student roll number and book code </td></tr>
			<?php } ?>
			</div>
		</div>
	</div>
	<?php 
	if(!(isset($_POST['search']) && $_POST['search']=="search")){echo "<br><br><br><br><br><br>";}
	else{echo "<br>";}
	?>
	
	<?php
	if(isset($_POST['return']) && $_POST['return']=="return"){
	//$data = "r_date=".$_POST['rdate'].", ldays=".$_POST['ldays'].", fine=".$_POST['fine'].", status='0'";
	//$data = "r_date=:'".$_POST['rdate']."',ldays=:'".$_POST['ldays']."',fine=:'".$_POST['fine']."',status=:'0',";
	$data = "r_date='".$_POST['rdate']."',ldays='".$_POST['ldays']."',fine='".$_POST['fine']."',status='0'";
	echo $data;
	/*$data = array(
			'r_date'=>$_POST['rdate'],
			'ldays'=>$_POST['ldays'],
			'fine'=>$_POST['fine'],
			'status'=>0,
	);
	
	$con = array(
		's_id'=>$_POST['s_code'],
		'b_id'=>$_POST['b_code'],
		'status'=>1,
	);*/
	$con = "s_id='".$_POST['s_code']."' and b_id = '".$_POST['b_code']."' and status='1'";
	//$update = $db->update('book_issue',$data,$con);
	//print_r($update);
	$update = $db->return_book($data,$con);
	//print_r($update);
	if($update){
	$change = $db->book_de_active($_POST['b_code']);
	if($change){echo "<script>location.replace('return-book.php?msg=rds')</script>";}
	else{echo "<script>location.replace('return-book.php?msg=rns')</script>";}
	}
	else{echo "<script>location.replace('return-book.php?msg=rxs')</script>";}
	}
	?>
	<br>