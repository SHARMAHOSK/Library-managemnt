<?php 
include_once('config.php');
if(isset($_REQUEST['delId']) and $_REQUEST['delId']!=""){
	$db->delete('s_info',array('s_id'=>$_REQUEST['delId']));
	header('location:students.php?msg=rds');
	exit;
}
?>